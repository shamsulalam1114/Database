SELECT AVG(TOTALEXPENSE) AS "Average Expense" FROM expenses;
