SELECT FlatNo, FIRSTNAME || ' ' || LASTNAME AS "Full Name"
FROM tenant;
