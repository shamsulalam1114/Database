UPDATE Dues
SET TotalExpense = TotalExpense + 100
WHERE FlatNo = 802;
commit;
